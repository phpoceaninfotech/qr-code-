-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2023 at 09:15 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qr_ocean`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `is_active` char(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `email`, `password`, `is_active`, `created_at`, `modified_at`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '1', '2018-12-29 06:40:08', '2023-07-04 10:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `id` int(11) NOT NULL,
  `company_name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `company_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `view_status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Deavtive',
  `add_status` varchar(200) NOT NULL DEFAULT 'Deavtive',
  `edit_status` varchar(200) NOT NULL DEFAULT 'Deavtive',
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `company_name`, `email`, `mobile`, `company_key`, `status`, `view_status`, `add_status`, `edit_status`, `last_update`) VALUES
(3, 'ocean infotech', 'ocean@gmail.com', '9080706050', 'ocean', 'Active', 'Deavtive', 'Deavtive', 'Deavtive', '2023-09-26 11:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `pro_name` longtext NOT NULL,
  `pro_code` text NOT NULL,
  `batch_no` text NOT NULL,
  `mfg_date` date NOT NULL,
  `retest_date` date NOT NULL,
  `exp_date` date NOT NULL,
  `drun_no` text NOT NULL,
  `tare_weight` text NOT NULL,
  `net_weight` text NOT NULL,
  `gross_weight` text NOT NULL,
  `container_code` text NOT NULL,
  `mfg_license_no` text NOT NULL,
  `mfg_name` longtext NOT NULL,
  `mfg_address` longtext NOT NULL,
  `storage_condition` longtext NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `pro_name`, `pro_code`, `batch_no`, `mfg_date`, `retest_date`, `exp_date`, `drun_no`, `tare_weight`, `net_weight`, `gross_weight`, `container_code`, `mfg_license_no`, `mfg_name`, `mfg_address`, `storage_condition`, `last_update`) VALUES
(1, 'hand wash', '1hand1235', '123', '2023-10-11', '2023-11-02', '2023-10-18', '123456', '200kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdfdsdsdfsdfsdsdsdff fe a daweerfffsdfsdfs', 'sdffsfsfsdfsdfsdfsdfsdsdfsdfsdfsdfsdfsdfsd', '2023-10-06 04:12:05'),
(2, 'hand wash', '1hand1235', '123', '2023-10-11', '2023-11-02', '2023-10-18', '123456', '200kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdfdsdsdfsdfsdsdsdff fe a daweerfffsdfsdfs', 'sdffsfsfsdfsdfsdfsdfsdsdfsdfsdfsdfsdfsdfsd', '2023-10-06 04:12:07'),
(3, 'hand wash', '1hand1235', '123', '2023-10-11', '2023-11-02', '2023-10-18', '123456', '200kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdfdsdsdfsdfsdsdsdff fe a daweerfffsdfsdfs', 'sdffsfsfsdfsdfsdfsdfsdsdfsdfsdfsdfsdfsdfsd', '2023-10-06 04:12:09'),
(4, 'hand wash', '1hand1235', '123', '2023-10-11', '2023-11-02', '2023-10-18', '123456', '200kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdfdsdsdfsdfsdsdsdff fe a daweerfffsdfsdfs', 'sdffsfsfsdfsdfsdfsdfsdsdfsdfsdfsdfsdfsdfsd', '2023-10-06 04:12:10'),
(5, 'hand wash', '1hand1235', '123', '2023-10-11', '2023-11-02', '2023-10-18', '123456', '200kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdfdsdsdfsdfsdsdsdff fe a daweerfffsdfsdfs', 'sdffsfsfsdfsdfsdfsdfsdsdfsdfsdfsdfsdfsdfsd', '2023-10-06 04:12:11'),
(6, 'sadasd', 'asdsad', 'sadas', '2023-10-18', '2023-10-27', '2023-10-07', '123456', '20kg', '300kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'sdsadas', '200kg', '2023-10-06 04:14:32'),
(7, 'hello', 'test123', '123', '2023-11-04', '2023-10-25', '2023-10-25', '123132', '20kg', '30kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'erefedfererterg ewr werfsdfsdf rfew rwe rwe we werw rrwr f dwsdrwsfefe', '200kg', '2023-10-06 04:15:44'),
(8, 'hello', 'test123', '123', '2023-11-04', '2023-10-25', '2023-10-25', '123132', '20kg', '30kg', '25kg', 'test123456', '2312313', 'ocean infotech', 'erefedfererterg ewr werfsdfsdf rfew rwe rwe we werw rrwr f dwsdrwsfefe', '200kg', '2023-10-06 04:15:47'),
(9, 'hello123', 'test123', '123', '2023-10-26', '2023-10-18', '2023-10-19', '123456', '200kg', '300kg', 'sdfsdfds', 'test123456', '2312313', 'ocean infotech', 'gfhfghfghfg', '111', '2023-10-06 04:18:08'),
(10, 'hello123', 'test123', '123', '2023-10-26', '2023-10-18', '2023-10-19', '123456', '200kg', '300kg', 'sdfsdfds', 'test123456', '2312313', 'ocean infotech', 'gfhfghfghfg', '111', '2023-10-06 04:18:09'),
(11, 'sdfsd', 'sdfsdf', 'sdfsdf', '2023-11-04', '2023-10-20', '2023-10-20', '123132', '32111', 'sdfsdf', '205kg', 'test123456', '2312313', 'ocean infotech', 'fsdfdsfsdfsd', '200kg', '2023-10-06 04:19:46'),
(12, 'hello', 'test123', '123', '2023-10-19', '2023-10-28', '2023-10-25', 'sdfsd', 'fsd', 'sdfsdf', 'dsf', 'ff', 'sdf132sdf13sddf', 'ocean infotech', 'sdfsdfsdfsd  fswf dsffsd fs fs f', '200kg', '2023-10-06 04:21:18'),
(13, 'hello', 'test123', '123', '2023-10-25', '2023-11-01', '2023-10-05', 'sdfsdf', '20kg', '300kg', '205kg', 'test123456', '2312313', 'ocean infotech', 'dfsfxdfxcvxcvxc', '200kg', '2023-10-06 04:24:41'),
(14, 'hello123456789', 'test123', '123', '2023-10-26', '2023-10-20', '2023-10-11', '123456', '200kg', '300kg', '205kg', 'fsdfsd', 'fsdfsd', 'sdfdsf', 'sdfsdfsd', 'fsdfsdf', '2023-10-06 04:40:13'),
(15, 'hello', 'test123', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', '', '', '2023-10-06 06:27:48'),
(16, 'hello', 'test123', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', '', '', '2023-10-06 06:28:13'),
(17, 'hello', 'test123', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', '', '', '2023-10-06 08:44:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
