<?php
include('../root/config.php');

$page_nm = "Inquiry";
$pageUrl = "inquiry.php";


if ($_GET['mode'] != '') {
$id = (int) $_REQUEST['id'];
    if ($_GET['id'] != '' && $_GET['mode'] == 'edit') {
            $editqry = "UPDATE tbl_inquiry SET 
        status='readed'
        WHERE id=".$id;
         
    $ai_db->aiQuery($editqry);
    $ai_core->aiGoPage($pageUrl . "?msg=2");
        }
    
  //delete record
    if ($_GET['mode'] == 'delete' && $id != '') 
  {
    
    
    $qry_del_su = "Delete from tbl_inquiry WHERE id=".$id;
        $ai_db->aiQuery($qry_del_su);
    
    $ai_core->aiGoPage($pageUrl . "?msg=3");
    }
  
} 
else
{
  //select all record
    $qry = "SELECT * FROM tbl_inquiry ORDER BY id DESC";
    $result = $ai_db->aiGetQueryObj($qry);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?></title>
  <!-- loader-->
  <link href="assets/css/pace.min.css" rel="stylesheet"/>
  <script src="assets/js/pace.min.js"></script>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!--Data Tables -->
  <link href="assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <link href="assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/parsley.css">
 
</head>

<body>

<!-- Start wrapper-->
 <div id="wrapper">

 <?php include('menu.php'); ?>  

<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Manage <?php echo $page_nm; ?></h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
         </ol>
     </div>
     <div class="col-sm-3">
       
     </div>
     </div>
    <!-- End Breadcrumb-->

      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> List Of <?php echo $page_nm; ?></div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
          <?php
          if (COUNT($result) > 0) {
            foreach ($result as $row) {
          ?>
                    <tr>
                        <td><?php echo $row->fname;?></td>
                        <td><?php echo $row->lname;?></td>
                        <td><?php echo $row->email;?></td>
                        <td><?php echo $row->phone;?></td>
                        <td><?php echo $row->subject;?></td>
                        <td><?php echo $row->message;?></td>
            <!-- <td><?php echo $row->status;
            if($row->status != 'readed'){
                          ?>
                          <a href="<?php echo $pageUrl . "?mode=edit&&id=".$row->id.""; ?>" class="btn btn-raised btn-success square btn-min-width mr-1 mb-1">Readed</a>
                          <?php } ?>
            </td> -->
            <td>
            <a href="<?php echo $pageUrl."?mode=delete&id=".$row->id.""; ?>" class="delete_check btn btn-danger m-1">Delete</a>
            </td>
                        
                    </tr>
                    <?php }}?>
                    
                </tbody>
                
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
     
    <!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->

   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2021 : <?php echo SITE_TITLE; ?>
        </div>
      </div>
    </footer>
  <!--End footer-->
  
  </div><!--End wrapper-->
  

  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
  
  <!--Data Tables js-->
  <script src="assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>
  
  <script src="assets/plugins/alerts-boxes/js/sweetalert.min.js"></script>
  <script src="assets/plugins/alerts-boxes/js/sweet-alert-script.js"></script>
  
  <script src="assets/parsley.min.js"></script>  
<script>
$('.delete_check').click(function(e){
  e.preventDefault();
    var link = $(this).attr('href');
  
  swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this record!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                  .then((willDelete) => {
                    if (willDelete) {
                      window.location.href = link; 
                    }
                  });
  
});
</script>

<?php
if ($_GET['msg'] == '1') {
?>
<script type="text/javascript">
swal("Good job!", "Record Added Successfully!", "success");
</script>
<?php } 
if ($_GET['msg'] == '2') {
?>
<script type="text/javascript">
swal("Updated!", "Record Updated Successfully!", "success");
</script>
<?php }
if ($_GET['msg'] == '3') {
?>
<script type="text/javascript">
swal("Deleted!", "Record Deleted Successfully!", "success");
</script>
<?php
}
?>




<script>
 $(document).ready(function() {
  //Default data table
   $('#default-datatable').DataTable();
   var table = $('#example').DataTable( {
  lengthChange: false,
  buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
  } );
 table.buttons().container()
  .appendTo( '#example_wrapper .col-md-6:eq(0)' );
  });

</script>
</body>
</html>
