<?php
include('root/config.php');
$page_nm = "QR-Prdouct";
$pageUrl = "manage_qr_product.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo SITE_TITLE; ?> - <?php echo $page_nm; ?></title>
  <!-- loader-->
  <link href="assets/css/pace.min.css" rel="stylesheet"/>
  <script src="assets/js/pace.min.js"></script>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!--Data Tables -->
  <link href="assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <link href="assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/parsley.css">
 
</head>
<body>
<!-- Start wrapper-->
<div id="wrapper">
<?php include('menu.php'); ?>	
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
      <div class="row pt-2 pb-2">
        <div class="col-sm-9">
  		    <h4 class="page-title">Manage <?php echo $page_nm; ?></h4>
  		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $page_nm; ?></li>
          </ol>
	      </div>
  	    <div class="col-sm-3">
          <div class="float-sm-right"></div>
        </div>
      </div>
      <!-- End Breadcrumb-->
	    <div class="row">
        <div class="col-12 col-lg-12 col-xl-12">
         
          <div class="card">
            <div class="card-header">Add <?php echo $page_nm; ?></div>
            <div class="card-body">
              <form class="row g-3" name="frm" id="frm">
                <div class="col-md-6 border-end">

                  <div class="col-md-12">
                    <label for="pro_name" class="col-form-label">Product name</label>
                    <div class="">
                      <input type="text" class="form-control" id="pro_name" name="pro_name" value="" placeholder="Enter Product Name" data-parsley-required="false">
                    </div>
                  </div>
          
                  <div class="col-md-12">
                    <label for="pro_code" class=" col-form-label">Product Code</label>
                    <div class="">
                      <input type="text" class="form-control" id="pro_code" name="pro_code" value="" placeholder="Enter Product Code" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="batch_no" class="col-form-label">Batch No.</label>
                    <div class="">
                      <input type="text" class="form-control" id="batch_no" name="batch_no" value="" placeholder="Enter Batch No." data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="mfg_date" class="col-form-label">MFG Date</label>
                    <div class="">
                      <input type="date" class="form-control" id="mfg_date" name="mfg_date" value="" placeholder="Enter MFG Date" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="retest_date" class="col-form-label">Re-Test Date</label>
                    <div class="">
                      <input type="date" class="form-control" id="retest_date" name="retest_date" value="" placeholder="Enter Re-Test Date" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="exp_date" class="col-form-label">Expiry Date</label>
                    <div class="">
                      <input type="date" class="form-control" id="exp_date" name="exp_date" value="" placeholder="Enter Expiry Date" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="drun_no" class="col-form-label">Drun No.</label>
                    <div class="">
                      <input type="text" class="form-control" id="drun_no" name="drun_no" value="" placeholder="Enter Drun No." data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="tare_weight" class="col-form-label">Tare Weight</label>
                    <div class="">
                      <input type="text" class="form-control" id="tare_weight" name="tare_weight" value="" placeholder="Enter Tare Weight" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="net_weight" class="col-form-label">Net Weight</label>
                    <div class="">
                      <input type="text" class="form-control" id="net_weight" name="net_weight" value="" placeholder="Enter Net Weight" data-parsley-required="false">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <label for="gross_weight" class="col-form-label">Gross Weight</label>
                    <div class="">
                      <input type="text" class="form-control" id="gross_weight" name="gross_weight" value="" placeholder="Enter Gross Weight" data-parsley-required="false">
                    </div>
                  </div>
              </div><!--end col-md-6-->
        
              <div class="col-md-6 border-start">
                <div class="col-md-12">
                  <label for="container_code" class="col-form-label">Container Code</label>
                  <div class="">
                    <input type="text" class="form-control" id="container_code" name="container_code" value="" placeholder="Enter Container Code" data-parsley-required="false">
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="mfg_license_no" class="col-form-label">MFG License No</label>
                  <div class="">
                    <input type="text" class="form-control" id="mfg_license_no" name="mfg_license_no" value="" placeholder="Enter MFG License No" data-parsley-required="false">
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="mfg_name" class="col-form-label">MFG Name</label>
                  <div class="">
                    <input type="text" class="form-control" id="mfg_name" name="mfg_name" value="" placeholder="Enter MFG Name" data-parsley-required="false">
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="storage_condition" class="col-form-label">Storage Condition</label>
                  <div class="">
                    <input type="text" class="form-control" id="storage_condition" name="storage_condition" value="" placeholder="Enter Storage Condition" data-parsley-required="false">
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="mfg_address" class="col-form-label">MFG Address</label>
                  <div class="">
                    <textarea type="text" class="form-control" id="mfg_address" name="mfg_address" placeholder="Enter MFG Address"></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <div class="" style="margin-left:80px; margin-top:30px;">
                    <button type="button" name="" id="btn_submit" class="btn btn-primary" 
                    onclick="generateqr()" ><i class="icon-plus"></i> Submit</button>

                    <a id='download' class="btn btn-info" style="color:#fff;"><i class="fa fa-download" ></i> Download</a> 

                    <a href="<?php echo $pageUrl; ?>" class="btn btn-warning"><i class="icon-minus"></i> Cancel</a>
                  </div>
                </div>
                <div id="qrcode" class="text-center"></div>
               </form>
            </div>
          </div>
        </div>
      </div>
    </div><!--End Row-->
    <!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
  </div>
  <!-- End container-fluid-->
  </div>
  <!--End content-wrapper-->

  <!--Start Back To Top Button-->
  <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
  <!--End Back To Top Button-->
  
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2021 : <?php echo SITE_TITLE; ?>
        </div>
      </div>
    </footer>
	<!--End footer-->
	
  </div><!--End wrapper-->
  

  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
  
  <!--Data Tables js-->
  <script src="assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>
  
  <script src="assets/plugins/alerts-boxes/js/sweetalert.min.js"></script>
  <script src="assets/plugins/alerts-boxes/js/sweet-alert-script.js"></script>
  
  <script src="assets/parsley.min.js"></script>  
<script>
$('.delete_check').click(function(e){
	e.preventDefault();
    var link = $(this).attr('href');
	
	swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this record!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                  .then((willDelete) => {
                    if (willDelete) {
                      window.location.href = link; 
                    }
                  });
	
});
</script>

<script>

    function generateqr() {
      var pro_name = document.getElementById('pro_name').value;
      var pro_code = document.getElementById('pro_code').value;
      var batch_no = document.getElementById('batch_no').value;
      var mfg_date = document.getElementById('mfg_date').value;
      var retest_date = document.getElementById('retest_date').value;
      var exp_date = document.getElementById('exp_date').value;
      var drun_no = document.getElementById('drun_no').value;
      var tare_weight = document.getElementById('tare_weight').value;
      var net_weight = document.getElementById('net_weight').value;
      var gross_weight = document.getElementById('gross_weight').value;
      var container_code = document.getElementById('container_code').value;
      var mfg_license_no = document.getElementById('mfg_license_no').value;
      var mfg_name = document.getElementById('mfg_name').value;
      var mfg_address = document.getElementById('mfg_address').value;
      var storage_condition = document.getElementById('storage_condition').value;

      //console.log('Name: ' + pro_name + " " + pro_code + " " + batch_no + " " + mfg_date + " " + retest_date + " " + exp_date + " " + drun_no + " " + tare_weight + " " + net_weight + " " +gross_weight + " " + container_code + " " + mfg_license_no  + " " + mfg_name + " " + mfg_address + " " + storage_condition);

      var url = "https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl= Product Name : " +
      pro_name + "%0a product code : " + pro_code + "%0a Batch No : " + batch_no + "%0a MFG Date : " + mfg_date + "%0a RE-Test Date : " + retest_date + "%0a Expiry Date : " + exp_date + "%0a Drun No : " + drun_no + "%0a Tare Weight : " + tare_weight + "%0a Net Weight : " + net_weight + "%0a Groos Weight : " + gross_weight + "%0a Container code : " + container_code + "%0a Manufactur License No : " + mfg_license_no + "%0a Manufactur Name : " + mfg_name + "%0a Manufactur Address : " + mfg_address + "%0a Storage Condition : " + storage_condition;

      var ifr = '<img src="'+ url +'" height="300" width="300"/>';

      document.getElementById('qrcode').innerHTML = ifr; 

      const url2 = url;      
      const target = document.getElementById('qrcode');
      const link = document.getElementById('download');

      const xhr = new XMLHttpRequest();

      xhr.addEventListener('loadend', (e) => {
        const blobUrl = URL.createObjectURL(e.target.response);
        target.src = blobUrl;
        link.href = blobUrl;
        link.download = 'image.png';
      });

      xhr.responseType = 'blob';
      xhr.open('GET', url2);
      xhr.send();
   }
  </script>

<?php
if ($_GET['msg'] == '1') {
?>
<script type="text/javascript">
swal("Good job!", "Record Added Successfully!", "success");
</script>
<?php } 
if ($_GET['msg'] == '2') {
?>
<script type="text/javascript">
swal("Updated!", "Record Updated Successfully!", "success");
</script>
<?php }
if ($_GET['msg'] == '3') {
?>
<script type="text/javascript">
swal("Deleted!", "Record Deleted Successfully!", "success");
</script>
<?php
}
?>

<script>
 $(document).ready(function() {
  //Default data table
   $('#default-datatable').DataTable();
   var table = $('#example').DataTable( {
	lengthChange: false,
	buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
  } );
 table.buttons().container()
	.appendTo( '#example_wrapper .col-md-6:eq(0)' );
  });

</script>

<script type="text/javascript">
  $(document).ready(function() {
    $("#btn_submit").click(function() {
    var pro_name = $("#pro_name").val();
    var pro_code = $("#pro_code").val();
    var batch_no = $("#batch_no").val();
    var mfg_date = $("#mfg_date").val();
    var retest_date = $("#retest_date").val();
    var exp_date = $("#exp_date").val();
    var drun_no = $("#drun_no").val();
    var tare_weight = $("#tare_weight").val();
    var net_weight = $("#net_weight").val();
    var gross_weight = $("#gross_weight").val();
    var container_code = $("#container_code").val();
    var mfg_license_no = $("#mfg_license_no").val();
    var mfg_name = $("#mfg_name").val();
    var mfg_address = $("#mfg_address").val();
    var storage_condition = $("#storage_condition").val();

    if (pro_name == '' || pro_code == '') {
      alert("Insertion Failed Some Fields are Blank....!!");
    } else {
    // Returns successful data submission message when the entered information is stored in database.
      $.post("product.php", {
      pro_name: pro_name,
      pro_code: pro_code,
      batch_no: batch_no,
      mfg_date: mfg_date,
      retest_date: retest_date,
      exp_date: exp_date,
      drun_no: drun_no,
      tare_weight: tare_weight,
      net_weight: net_weight,
      gross_weight: gross_weight,
      container_code: container_code,
      mfg_license_no: mfg_license_no,
      mfg_name: mfg_name,
      mfg_address: mfg_address,
      storage_condition: storage_condition
      }, function(data) {
      html(data);
      $('#frm')[0].reset(); // To reset form fields
      });
      }
    });
  });
</script>

</body>
</html>
<!-- 
https://www.knowband.com/blog/tips/generate-qr-code-using-php/ 
<a download="${url}" href="${url}"><i class="fa fa-download"></i></a>
'<a href="'+ifr+'" target="_blank" download="'+ifr+'"><i class="fa fa-download"></i></a>';
-->