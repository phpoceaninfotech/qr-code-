<!--Start sidebar-wrapper-->
<?php
if ($_SESSION['aid'] == "") {
    ?>
    <script type="text/javascript">
        document.location.href = 'index.php';
    </script>
    <?php
}
?>
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
   
    <div class="brand-logo">
	  <img src="assets/images/logo.png" class="logo-icon" alt="logo icon">
	  <!-- <h5 class="logo-text"><?php //echo SITE_TITLE; ?></h5> -->
	  <div class="close-btn"><i class="zmdi zmdi-close"></i></div>
   </div>
	  
     <ul class="metismenu" id="menu">
		<li>
		  <a class="" href="dashboard.php">
			<div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
			<div class="menu-title">Dashboard</div>
		  </a>
		</li>

		<li>
		  <a class="has-arrow" href="javascript:void();">
		 <div class="parent-icon"> <i class='zmdi zmdi-format-list-bulleted'></i></div>
		   <div class="menu-title">Manage Company</div>
		  </a>
		  <ul>
			<li>
				<a href="manage_company.php"><i class="zmdi zmdi-dot-circle-alt"></i>Add Company</a>
			</li>
		  </ul>
		</li>

		 <!-- <li>
		  <a class="has-arrow" href="javascript:void();">
		  <div class="parent-icon"> <i class='zmdi zmdi-format-list-bulleted'></i></div>
		  <div class="menu-title">Manage Product</div>
		  </a>
		  <ul>
			<li>
				<a href="manage_product.php"><i class="zmdi zmdi-dot-circle-alt"></i>Add Product</a>
			</li>
		  </ul>
		</li> -->
		
		<li>
		  <a class="has-arrow" href="javascript:void();">
		  <div class="parent-icon"> <i class='zmdi zmdi-format-list-bulleted'></i></div>
		  <div class="menu-title">QR-Code Genrarate</div>
		  </a>
		  <ul>
			<li>
				<a href="manage_qr_product.php"><i class="zmdi zmdi-dot-circle-alt"></i> QR-Code</a>
			</li>
		  </ul>
		</li>

	<!--	<li>
		  <a class="has-arrow" href="javascript:void();">
		  <div class="parent-icon"> <i class='zmdi zmdi-format-list-bulleted'></i></div>
		  <div class="menu-title">Manage Index Portfolio</div>
		  </a>
		  <ul>
			<li><a href="manage_index_portfolio.php"><i class="zmdi zmdi-dot-circle-alt"></i>Index Portfolio
			</a></li>
		  </ul>
		</li>

		<li>
		  <a class="has-arrow" href="javascript:void();">
		 <div class="parent-icon"> <i class='zmdi zmdi-layers'></i></div>
		   <div class="menu-title">Other</div>
		  </a>
		  <ul>
			<li>
				<a href="manage_portfolio_category.php"><i class="zmdi zmdi-dot-circle-alt"></i> Manage Portfolio Category</a>
			</li>
			<li>
				<a href="manage_blog_category.php"><i class="zmdi zmdi-dot-circle-alt"></i> Manage Blogs Category</a>
			</li>
			<li>
				<a href="manage_pincode.php"><i class="zmdi zmdi-dot-circle-alt"></i> Manage Pincode</a>
			</li>
			 <li>
				<a href="manage_roles.php"><i class="zmdi zmdi-dot-circle-alt"></i> Manage Roles</a>
			</li> 
		  </ul>
		</li>
		<li>
		  <a class="" href="inquiry.php">
			<div class="parent-icon"><i class="zmdi zmdi-email"></i></div>
			<div class="menu-title">Inquiry</div>
			<div class="badge badge-light ml-auto"><?php 
			// $app_qry = "SELECT count(*) as total_count FROM tbl_inquiry ";
			// $app_row = $ai_db->aiGetQuery($app_qry);
			// echo $app_row[0]['total_count'];
			?></div>
		  </a>
		</li>-->
		
	<!-- 	<li>
		  <a class="" href="product_enquiry.php">
			<div class="parent-icon"><i class="zmdi zmdi-email"></i></div>
			<div class="menu-title">Product Inquiry</div>
			<div class="badge badge-light ml-auto"><?php 
// $app_qry1 = "SELECT count(*) as total_count FROM tbl_product_inquiry ";
// $app_row1 = $ai_db->aiGetQuery($app_qry1);
// echo $app_row1[0]['total_count'];
?></div>
		  </a>
		</li>
		<li>
		  <a class="" href="product_enquiry_app.php">
			<div class="parent-icon"><i class="zmdi zmdi-email"></i></div>
			<div class="menu-title">Product Inquiry APP</div>
			<div class="badge badge-light ml-auto"><?php 
// $app_qry2 = "SELECT count(*) as total_count FROM tbl_product_inquiry_app ";
// $app_row2 = $ai_db->aiGetQuery($app_qry2);
// echo $app_row2[0]['total_count'];
?></div>
		  </a>
		</li>
		</ul> -->
   
   </div>
   <!--End sidebar-wrapper-->

<!--Start topbar header-->
<header class="topbar-nav">
 <nav id="header-setting" class="navbar navbar-expand fixed-top">
 
	 <div class="toggle-menu">
		 <i class="zmdi zmdi-menu"></i>
	 </div>
	 
     
   <ul class="navbar-nav align-items-center right-nav-link ml-auto">
	<li class="nav-item dropdown search-btn-mobile">
		<a class="nav-link position-relative" href="javascript:void();">
		  <i class="zmdi zmdi-search align-middle"></i>
		</a>
	 </li>
    
    
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" data-toggle="dropdown" href="javascript:void();">
        <span class="user-profile"><img src="assets/images/use_icon.png" class="img-circle" alt="user avatar"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-right">
       <li class="dropdown-item user-details">
        <a href="javaScript:void();">
           <div class="media">
             <div class="avatar"><img class="align-self-start mr-3" src="assets/images/use_icon.png" alt="user avatar"></div>
            <div class="media-body">
            <h6 class="mt-2 user-title"><?php echo $_SESSION['username']; ?></h6>
            <p class="user-subtitle"><?php echo $_SESSION['email']; ?></p>
            </div>
           </div>
          </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="profile.php"><i class="zmdi zmdi-balance-wallet mr-3"></i>Profile</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="logout.php"><i class="zmdi zmdi-power mr-3"></i>Logout</a></li>
      </ul>
    </li>
  </ul>
</nav>
</header>