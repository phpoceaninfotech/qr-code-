<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
require_once 'root/config.php';
//$pageUrl = 'manage_qr_product.php';

$pro_name = $_POST['pro_name'];
$pro_code = $_POST['pro_code'];
$batch_no = $_POST['batch_no'];
$mfg_date = $_POST['mfg_date'];
$retest_date = $_POST['retest_date'];
$exp_date = $_POST['exp_date'];
$drun_no = $_POST['drun_no'];
$tare_weight = $_POST['tare_weight'];
$net_weight = $_POST['net_weight'];
$gross_weight = $_POST['gross_weight'] ;
$container_code = $_POST['container_code'];
$mfg_license_no = $_POST['mfg_license_no'];
$mfg_name = $_POST['mfg_name'] ;
$mfg_address = $_POST['mfg_address'];
$storage_condition = $_POST['storage_condition'];

  $add_qry = "INSERT INTO tbl_product SET
                  pro_name='".$pro_name."',
                 pro_code='".$pro_code."',
                  batch_no='".$batch_no."',
                 mfg_date='".$mfg_date."',
                 retest_date='".$retest_date."',
                 exp_date='".$exp_date."',
                 drun_no='".$drun_no."',
                 tare_weight='".$tare_weight."',
                 net_weight='".$net_weight."',
                 gross_weight='".$gross_weight."',
                 container_code='".$container_code."',
                 mfg_license_no='".$mfg_license_no."',
                 mfg_name='".$mfg_name."',
                 mfg_address='".$mfg_address."',
                 storage_condition='".$storage_condition."'";
                 $ai_db->aiQuery($add_qry);

?>
<?php
//|| batch_no == '' || mfg_date == '' || retest_date == '' || exp_date == '' || drun_no == '' || tare_weight == ''|| net_weight == ''|| gross_weight == '' ||container_code == '' || mfg_license_no == '' || mfg_name == ''|| mfg_address == ''|| storage_condition == ''
// require_once 'phpqrcode/qrlib.php';
// $path = 'images/';
// $qrcode = $path.time().".png";
// $qrimage = time().".png";

// if(isset($_REQUEST['btn_submit']))
// {
//   $codeString = $_POST['pro_name'] . "\n";
//   $codeString .= $_POST['pro_code'] . "\n";
//   $codeString .= $_POST['batch_no'] . "\n";
//   $codeString .= $_POST['mfg_date'] . "\n";
//   $codeString .= $_POST['retest_date'] . "\n";
//   $codeString .= $_POST['exp_date'] . "\n";
//   $codeString .= $_POST['drun_no'] . "\n";
//   $codeString .= $_POST['tare_weight'] . "\n";
//   $codeString .= $_POST['net_weight'] . "\n";
//   $codeString .= $_POST['gross_weight'] . "\n";
//   $codeString .= $_POST['container_code'] . "\n";
//   $codeString .= $_POST['mfg_license_no'] . "\n";
//   $codeString .= $_POST['mfg_name'] . "\n";
//   $codeString .= $_POST['mfg_address']. "\n";
//   $codeString .= $_POST['storage_condition'];


// QRcode :: png($codeString, $qrcode, 'H', 4, 4);
// echo "<img src='".$qrcode."'>";
// }

 // <script type="text/javascript"> -->
    // var pro_name = $("#pro_name").val();
    // var pro_code = $("#pro_code").val();
    // var batch_no = $("#batch_no").val();
    // var mfg_date = $("#mfg_date").val();
    // var retest_date = $("#retest_date").val();

    // var exp_date = $("#exp_date").val();
    // var drun_no = $("#drun_no").val();
    // var tare_weight = $("#tare_weight").val();
    // var net_weight = $("#net_weight").val();
    // var gross_weight = $("#gross_weight").val();

    // var container_code = $("#container_code").val();
    // var mfg_license_no = $("#mfg_license_no").val();
    // var mfg_name = $("#mfg_name").val();
    // var mfg_address = $("#mfg_address").val();
    // var storage_condition = $("#storage_condition").val();




      // var pro_name = document.getElementById('pro_name').value;
      // var pro_code = document.getElementById('pro_code').value;
      // var batch_no = document.getElementById('batch_no').value;
      // var mfg_date = document.getElementById('mfg_date').value;

      // var retest_date = document.getElementById('retest_date').value;
      // var exp_date = document.getElementById('exp_date').value;
      // var drun_no = document.getElementById('drun_no').value;
      // var tare_weight = document.getElementById('tare_weight').value;

      // var net_weight = document.getElementById('net_weight').value;
      // var gross_weight = document.getElementById('gross_weight').value;
      // var container_code = document.getElementById('container_code').value;
      // var mfg_license_no = document.getElementById('mfg_license_no').value;
      
      // var mfg_name = document.getElementById('mfg_name').value;
      // var mfg_address = document.getElementById('mfg_address').value;
      // var storage_condition = document.getElementById('storage_condition').value;

// </script> -->